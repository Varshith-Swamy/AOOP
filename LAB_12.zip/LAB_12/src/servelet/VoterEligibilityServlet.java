package servelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VoterEligibilityServlet")
public class VoterEligibilityServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");

        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");

        try {
            int age = Integer.parseInt(ageStr);

            if (age < 0) {
                response.getWriter().println("Invalid input: Age cannot be negative.");
                return;
            }

            if (age >= 18) {
                response.getWriter().println("Hello " + name + ", you are eligible to vote!");
            } else {
                response.getWriter().println("Hello " + name + ", you are not eligible to vote yet.");
            }
        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid input: Please enter a valid age.");
        }
    }
}

