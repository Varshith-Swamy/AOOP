package ContactMangement;

public class Client {
    public static void main(String[] args) {
        ContactManager contactManager = new ContactManager();

        // Adding contacts
        contactManager.addContact(new Contact("Varshith", "123-456-7890", "Varshith@example.com"));
        contactManager.addContact(new Contact("Harsha", "987-654-3210", "Harsha@example.com"));
        contactManager.addContact(new Contact("Hari", "555-555-5555", "Hari@example.com"));

        System.out.println("All contacts:");
        contactManager.printAllContacts();

        // Finding a contact by name
        Contact foundContact = contactManager.findContactByName("Bob");
        System.out.println("\nFound contact: " + foundContact);

        // Removing a contact
        boolean removed = contactManager.removeContact("Alice");
        System.out.println("\nContact 'Bitla' removed: " + removed);

        System.out.println("\nAll contacts after removal:");
        contactManager.printAllContacts();
    }
}
