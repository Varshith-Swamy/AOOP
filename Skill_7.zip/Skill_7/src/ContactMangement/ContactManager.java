package ContactMangement;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContactManager {
    private Set<Contact> contactsSet;
    private Map<String, Contact> contactsMap;

    public ContactManager() {
        contactsSet = new HashSet<>();
        contactsMap = new HashMap<>();
    }

    // Add a new contact
    public boolean addContact(Contact contact) {
        if (contactsSet.add(contact)) {
            contactsMap.put(contact.getName(), contact);
            return true;
        }
        return false;
    }

    // Remove a contact
    public boolean removeContact(String name) {
        Contact contact = contactsMap.remove(name);
        if (contact != null) {
            contactsSet.remove(contact);
            return true;
        }
        return false;
    }

    // Find a contact by name
    public Contact findContactByName(String name) {
        return contactsMap.get(name);
    }

    // Get all contacts
    public Set<Contact> getAllContacts() {
        return contactsSet;
    }

    // Print all contacts
    public void printAllContacts() {
        for (Contact contact : contactsSet) {
            System.out.println(contact);
        }
    }
}

