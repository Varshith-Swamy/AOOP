/**
 * 
 */
/**
 * 
 */
module LAB_1A {
}