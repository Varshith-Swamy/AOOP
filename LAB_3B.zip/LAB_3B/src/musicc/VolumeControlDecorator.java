package musicc;

class VolumeControlDecorator extends MusicPlayerDecorator {
    public VolumeControlDecorator(MusicPlayer musicPlayer) {
        super(musicPlayer);
    }

    @Override
    public void playMusic() {
        System.out.println("Setting volume level");
        super.playMusic();
    }

    @Override
    public void stopMusic() {
        super.stopMusic();
    }
}