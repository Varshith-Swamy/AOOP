package musicc;

class EqualizerDecorator extends MusicPlayerDecorator {
    public EqualizerDecorator(MusicPlayer musicPlayer) {
        super(musicPlayer);
    }

    @Override
    public void playMusic() {
        System.out.println("Applying equalizer settings");
        super.playMusic();
    }

    @Override
    public void stopMusic() {
        super.stopMusic();
    }
}
