package musicc;

abstract class MusicPlayerDecorator extends MusicPlayer {
    protected MusicPlayer musicPlayer;

    public MusicPlayerDecorator(MusicPlayer musicPlayer) {
        super(musicPlayer.musicSource);
        this.musicPlayer = musicPlayer;
    }

    @Override
    public void playMusic() {
        musicPlayer.playMusic();
    }

    @Override
    public void stopMusic() {
        musicPlayer.stopMusic();
    }
}
