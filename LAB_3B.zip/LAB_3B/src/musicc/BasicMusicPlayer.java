package musicc;

class BasicMusicPlayer extends MusicPlayer {
    public BasicMusicPlayer(MusicSource musicSource) {
        super(musicSource);
    }

    @Override
    public void playMusic() {
        musicSource.play();
    }

    @Override
    public void stopMusic() {
        musicSource.stop();
    }
}