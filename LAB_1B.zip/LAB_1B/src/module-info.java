/**
 * 
 */
/**
 * 
 */
module LAB_1B {
}