package SDP;

public class LoginManager {
    // Private static instance of LoginManager
    private static LoginManager instance;

    // Variable to track the login state
    private boolean isLoggedIn;
    private String loggedInUser;

    // Private constructor to prevent instantiation
    private LoginManager() {
        isLoggedIn = false;
    }

    // Public static method to get the single instance of LoginManager
    public static LoginManager getInstance() {
        if (instance == null) {
            synchronized (LoginManager.class) {
                if (instance == null) {
                    instance = new LoginManager();
                }
            }
        }
        return instance;
    }

    // Method to log in the user
    public void login(String username) {
        if (!isLoggedIn) {
            loggedInUser = username;
            isLoggedIn = true;
            System.out.println(username + " logged in successfully.");
        } else {
            System.out.println("A user is already logged in.");
        }
    }

    // Method to log out the user
    public void logout() {
        if (isLoggedIn) {
            System.out.println(loggedInUser + " logged out successfully.");
            loggedInUser = null;
            isLoggedIn = false;
        } else {
            System.out.println("No user is logged in.");
        }
    }

    // Method to check if a user is logged in
    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    // Method to get the logged-in user's name
    public String getLoggedInUser() {
        return loggedInUser;
    }
}

