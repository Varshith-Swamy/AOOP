package SDP;

public class BankOperations {
    // Method to view balance
    public void viewBalance() {
        LoginManager loginManager = LoginManager.getInstance();
        if (loginManager.isLoggedIn()) {
            System.out.println("Balance for " + loginManager.getLoggedInUser() + ": Rs.1000");
        } else {
            System.out.println("Please log in to view your balance.");
        }
    }

    // Method to deposit money
    public void deposit(double amount) {
        LoginManager loginManager = LoginManager.getInstance();
        if (loginManager.isLoggedIn()) {
            System.out.println(loginManager.getLoggedInUser() + " deposited Rs." + amount);
        } else {
            System.out.println("Please log in to deposit money.");
        }
    }

    // Method to withdraw money
    public void withdraw(double amount) {
        LoginManager loginManager = LoginManager.getInstance();
        if (loginManager.isLoggedIn()) {
            System.out.println(loginManager.getLoggedInUser() + " withdrew Rs." + amount);
        } else {
            System.out.println("Please log in to withdraw money.");
        }
    }
}

