package SDP;

public class Main {
    public static void main(String[] args) {
        LoginManager loginManager = LoginManager.getInstance();

        // User tries to perform operations without logging in
        BankOperations bankOperations = new BankOperations();
        bankOperations.viewBalance(); // Should prompt to log in
        bankOperations.deposit(500);  // Should prompt to log in
        bankOperations.withdraw(200); // Should prompt to log in

        // User logs in
        loginManager.login("Varshith");

        // User performs operations after logging in
        bankOperations.viewBalance(); // Should show balance
        bankOperations.deposit(500);  // Should confirm deposit
        bankOperations.withdraw(200); // Should confirm withdrawal

        // User logs out
        loginManager.logout();

        // User tries to perform operations after logging out
        bankOperations.viewBalance(); // Should prompt to log in
    }
}

