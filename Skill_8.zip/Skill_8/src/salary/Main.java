package salary;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("Ramu", 50000),
            new Employee("Aravind", 75000),
            new Employee("Bharath", 45000),
            new Employee("Charan", 82000),
            new Employee("Dinesh", 54000),
            new Employee("Raghu", 67000),
            new Employee("Farukh", 90000),
            new Employee("Ganesh", 58000),
            new Employee("Harish", 76000),
            new Employee("Ishant", 60000)
        );

        List<Employee> filteredEmployees = employees.stream()
            .filter(emp -> emp.getSalary() > 60000)
            .collect(Collectors.toList());

        System.out.println("Employees with salary greater than 60,000:");
        filteredEmployees.forEach(System.out::println);

        List<Employee> sortedEmployees = employees.stream()
            .sorted(Comparator.comparing(Employee::getSalary))
            .collect(Collectors.toList());

        System.out.println("\nEmployees sorted by salary:");
        sortedEmployees.forEach(System.out::println);

        Optional<Employee> highestSalaryEmployee = employees.stream()
            .max(Comparator.comparing(Employee::getSalary));

        highestSalaryEmployee.ifPresent(emp -> 
            System.out.println("\nEmployee with the highest salary: " + emp)
        );

        double averageSalary = employees.stream()
            .mapToDouble(Employee::getSalary)
            .average()
            .orElse(0.0);

        System.out.println("\nAverage salary: " + averageSalary);
    }
}
