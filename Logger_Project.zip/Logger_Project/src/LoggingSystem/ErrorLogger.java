package LoggingSystem;

public class ErrorLogger extends Logger {

    public ErrorLogger(LogLevel logLevel) {
        super(logLevel);
    }

    @Override
    protected void write(String message) {
        System.err.println("ErrorLogger: " + message);
    }
}

