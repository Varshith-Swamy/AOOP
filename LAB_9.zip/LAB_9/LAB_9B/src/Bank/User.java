package Bank;

public class User implements Runnable {
    private BankAccount account;

    public User(BankAccount account) {
        this.account = account;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {  // Each user will perform 5 transactions
            double amount = Math.random() * 100;
            if (Math.random() > 0.5) {
                account.deposit(amount);
            } else {
                account.withdraw(amount);
            }

            // Simulate some delay
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
