package numbers;

public class Printer {
    private int currentNumber = 1;

    public synchronized void print(int divisor, String message) {
        while (currentNumber <= 15) {
            if (currentNumber % divisor == 0) {
                System.out.println(message + ": " + currentNumber);
                currentNumber++;
                notifyAll();
            } else if (divisor == 0) {  // For printNumber thread
                if (currentNumber % 2 != 0 && currentNumber % 3 != 0 &&
                    currentNumber % 4 != 0 && currentNumber % 5 != 0) {
                    System.out.println("Number: " + currentNumber);
                    currentNumber++;
                    notifyAll();
                } else {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
