package numbers;

public class PrintFour implements Runnable {
    private Printer printer;

    public PrintFour(Printer printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        printer.print(4, "Divisible by 4");
    }
}
