package numbers;

public class PrintNumber implements Runnable {
    private Printer printer;

    public PrintNumber(Printer printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        printer.print(0, "Number");
    }
}
