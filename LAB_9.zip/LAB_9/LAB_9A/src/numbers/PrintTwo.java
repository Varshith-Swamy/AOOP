package numbers;

public class PrintTwo implements Runnable {
    private Printer printer;

    public PrintTwo(Printer printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        printer.print(2, "Divisible by 2");
    }
}

