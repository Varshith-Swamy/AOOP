package numbers;

public class PrintFive implements Runnable {
    private Printer printer;

    public PrintFive(Printer printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        printer.print(5, "Divisible by 5");
    }
}

