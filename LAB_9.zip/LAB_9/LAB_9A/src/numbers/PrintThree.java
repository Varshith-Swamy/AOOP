package numbers;

public class PrintThree implements Runnable {
    private Printer printer;

    public PrintThree(Printer printer) {
        this.printer = printer;
    }

    @Override
    public void run() {
        printer.print(3, "Divisible by 3");
    }
}

