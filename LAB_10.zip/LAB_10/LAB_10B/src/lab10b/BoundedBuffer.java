package lab10b;

class BoundedBuffer {
    private final int[] buffer; // Buffer array to store items
    private int count, in, out; // Count: number of items, in: index to insert, out: index to remove

    public BoundedBuffer(int size) {
        buffer = new int[size];
        count = in = out = 0;
    }

    // Method to add item to buffer
    public synchronized void produce(int item) throws InterruptedException {
        while (count == buffer.length) {
            System.out.println("Buffer is full, producer waiting...");
            wait(); // Wait until space is available in the buffer
        }

        buffer[in] = item; // Add item to buffer
        in = (in + 1) % buffer.length; // Circular buffer logic
        count++; // Increment item count
        System.out.println("Produced: " + item);

        notify(); // Notify the consumer that an item is available
    }

    // Method to remove item from buffer
    public synchronized int consume() throws InterruptedException {
        while (count == 0) {
            System.out.println("Buffer is empty, consumer waiting...");
            wait(); // Wait until there's an item to consume
        }

        int item = buffer[out]; // Remove item from buffer
        out = (out + 1) % buffer.length; // Circular buffer logic
        count--; // Decrement item count
        System.out.println("Consumed: " + item);

        notify(); // Notify the producer that space is available
        return item;
    }
}
