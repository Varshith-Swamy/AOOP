/**
 * 
 */
/**
 * 
 */
module LAB_10B {
}