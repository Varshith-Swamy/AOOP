package lab10;

import java.util.concurrent.BlockingQueue;

// Producer class
class Producer implements Runnable {
    private BlockingQueue<String> sharedBuffer;
    private int messageCount;

    public Producer(BlockingQueue<String> sharedBuffer, int messageCount) {
        this.sharedBuffer = sharedBuffer;
        this.messageCount = messageCount;
    }

    @Override
    public void run() {
        for (int i = 1; i <= messageCount; i++) {
            try {
                String message = "Message " + i;
                sharedBuffer.put(message); // Put message into the buffer
                System.out.println("Produced: " + message);
                Thread.sleep(500); // Simulating time to produce a message
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        try {
            sharedBuffer.put("END"); // Signaling the end of message production
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}