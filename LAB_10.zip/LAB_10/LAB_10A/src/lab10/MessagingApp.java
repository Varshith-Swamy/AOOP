package lab10;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class MessagingApp {
    public static void main(String[] args) {
        BlockingQueue<String> buffer = new ArrayBlockingQueue<>(10); // Shared buffer with size 10

        Producer producer = new Producer(buffer, 5); // Producer will produce 5 messages
        Consumer consumer = new Consumer(buffer);

        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);

        producerThread.start();
        consumerThread.start();

        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}