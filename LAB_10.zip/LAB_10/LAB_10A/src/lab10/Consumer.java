package lab10;

import java.util.concurrent.BlockingQueue;

class Consumer implements Runnable {
    private BlockingQueue<String> sharedBuffer;

    public Consumer(BlockingQueue<String> sharedBuffer) {
        this.sharedBuffer = sharedBuffer;
    }

    @Override
    public void run() {
        try {
            String message;
            while (!(message = sharedBuffer.take()).equals("END")) {
                System.out.println("Consumed: " + message);
                Thread.sleep(1000); // Simulating time to consume a message
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
