package music;

public class MusicStreamingApp {
    public static void main(String[] args) {
        // Using Local File Adapter
        MusicSource localFileMusic = new LocalFileAdapter();
        MusicSource localFileWithEqualizer = new EqualizerDecorator(localFileMusic);
        localFileWithEqualizer.play();
        localFileWithEqualizer.stop();

        // Using Online Streaming Adapter with Volume Control
        MusicSource onlineStreamingMusic = new OnlineStreamingAdapter();
        MusicSource onlineStreamingWithVolumeControl = new VolumeControlDecorator(onlineStreamingMusic);
        onlineStreamingWithVolumeControl.play();
        onlineStreamingWithVolumeControl.stop();

        // Using Radio Station Adapter with both Equalizer and Volume Control
        MusicSource radioMusic = new RadioStationAdapter();
        MusicSource radioWithAllFeatures = new VolumeControlDecorator(new EqualizerDecorator(radioMusic));
        radioWithAllFeatures.play();
        radioWithAllFeatures.stop();
    }
}
