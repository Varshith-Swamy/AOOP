package music;

//Adaptee class for Local File
class LocalFilePlayer {
 public void playLocalFile() {
     System.out.println("Playing music from a local file.");
 }

 public void stopLocalFile() {
     System.out.println("Stopped playing music from a local file.");
 }
}

//Adapter class for Local File
