package music;

//Common interface for all music sources
public interface MusicSource {
 void play();
 void stop();
}
