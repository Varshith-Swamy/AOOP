package CO2;

import java.util.Comparator;
import java.util.List;

public class Sorter {
    
    // Nested Comparator classes
    static class NameComparator implements Comparator<Item> {
        @Override
        public int compare(Item i1, Item i2) {
            return i1.getName().compareTo(i2.getName());
        }
    }

    static class QuantityComparator implements Comparator<Item> {
        @Override
        public int compare(Item i1, Item i2) {
            return Integer.compare(i1.getQuantity(), i2.getQuantity());
        }
    }

    static class PriceComparator implements Comparator<Item> {
        @Override
        public int compare(Item i1, Item i2) {
            return Double.compare(i1.getPrice(), i2.getPrice());
        }
    }

    // Lambda-based dynamic sorting
    public void dynamicSort(List<Item> items, String criterion) {
        Comparator<Item> comparator = switch (criterion) {
            case "name" -> Comparator.comparing(Item::getName);
            case "quantity" -> Comparator.comparingInt(Item::getQuantity);
            case "price" -> Comparator.comparingDouble(Item::getPrice);
            default -> throw new IllegalArgumentException("Invalid criterion");
        };

        items.sort(comparator);
    }

    // Sort using nested classes
    public void sortByName(List<Item> items) {
        items.sort(new NameComparator());
    }

    public void sortByQuantity(List<Item> items) {
        items.sort(new QuantityComparator());
    }

    public void sortByPrice(List<Item> items) {
        items.sort(new PriceComparator());
    }
}
