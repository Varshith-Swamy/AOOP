package CO2;

import java.util.ArrayList;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        // Create items
        List<Item> items = new ArrayList<>();
        items.add(new Item("Apple", 10, 1.99));
        items.add(new Item("Banana", 5, 0.99));
        items.add(new Item("Cherry", 20, 2.99));

        Sorter sorter = new Sorter();

        // Sort using lambda expressions (dynamic sorting)
        System.out.println("Sorting by name:");
        sorter.dynamicSort(items, "name");
        items.forEach(System.out::println);

        System.out.println("\nSorting by quantity:");
        sorter.dynamicSort(items, "quantity");
        items.forEach(System.out::println);

        System.out.println("\nSorting by price:");
        sorter.dynamicSort(items, "price");
        items.forEach(System.out::println);

        // Sort using nested classes
        System.out.println("\nSorting by name (nested class):");
        sorter.sortByName(items);
        items.forEach(System.out::println);

        System.out.println("\nSorting by quantity (nested class):");
        sorter.sortByQuantity(items);
        items.forEach(System.out::println);

        System.out.println("\nSorting by price (nested class):");
        sorter.sortByPrice(items);
        items.forEach(System.out::println);
    }
}
