package task;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ToDoListApplication {
    public static void main(String[] args) {
        List<String> toDoList = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add Task");
            System.out.println("2. Update Task");
            System.out.println("3. Remove Task");
            System.out.println("4. Display Tasks");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter task description: ");
                    toDoList.add(scanner.nextLine());
                    break;
                case 2:
                    System.out.print("Enter task index to update: ");
                    int indexToUpdate = scanner.nextInt();
                    scanner.nextLine();  
                    if (indexToUpdate >= 0 && indexToUpdate < toDoList.size()) {
                        System.out.print("Enter new task description: ");
                        toDoList.set(indexToUpdate, scanner.nextLine());
                    } else {
                        System.out.println("Invalid task index.");
                    }
                    break;
                case 3:
                    System.out.print("Enter task index to remove: ");
                    int indexToRemove = scanner.nextInt();
                    if (indexToRemove >= 0 && indexToRemove < toDoList.size()) {
                        toDoList.remove(indexToRemove);
                    } else {
                        System.out.println("Invalid task index.");
                    }
                    break;
                case 4:
                    System.out.println("\nTo-Do List:");
                    for (int i = 0; i < toDoList.size(); i++) {
                        System.out.println(i + ": " + toDoList.get(i));
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
