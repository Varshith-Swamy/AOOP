package task;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;

public class BrowsingHistory {
    public static void main(String[] args) {
        Deque<String> history = new ArrayDeque<>();
        Scanner scanner = new Scanner(System.in);
        String currentPage = null;

        int choice;
        do {
            System.out.println("\n1. Visit New Page");
            System.out.println("2. Go Back");
            System.out.println("3. Go Forward");
            System.out.println("4. Display Current Page");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    if (currentPage != null) {
                        history.addFirst(currentPage);
                    }
                    System.out.print("Enter page URL: ");
                    currentPage = scanner.nextLine();
                    break;
                case 2:
                    if (!history.isEmpty()) {
                        history.addLast(currentPage);
                        currentPage = history.pollFirst();
                    } else {
                        System.out.println("No previous pages.");
                    }
                    break;
                case 3:
                    if (!history.isEmpty()) {
                        history.addFirst(currentPage);
                        currentPage = history.pollLast();
                    } else {
                        System.out.println("No forward pages.");
                    }
                    break;
                case 4:
                    System.out.println("Current Page: " + (currentPage == null ? "No page visited" : currentPage));
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
