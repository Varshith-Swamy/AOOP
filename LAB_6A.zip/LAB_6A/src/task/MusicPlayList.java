package task;

import java.util.LinkedList;
import java.util.Scanner;

public class MusicPlayList {
    public static void main(String[] args) {
        LinkedList<String> playlist = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add Song");
            System.out.println("2. Remove Song");
            System.out.println("3. Move Song");
            System.out.println("4. Display Playlist");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    System.out.print("Enter song name: ");
                    playlist.add(scanner.nextLine());
                    break;
                case 2:
                    System.out.print("Enter song name to remove: ");
                    String songToRemove = scanner.nextLine();
                    if (playlist.remove(songToRemove)) {
                        System.out.println("Song removed.");
                    } else {
                        System.out.println("Song not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter current song position: ");
                    int currentPosition = scanner.nextInt();
                    System.out.print("Enter new song position: ");
                    int newPosition = scanner.nextInt();
                    if (currentPosition >= 0 && currentPosition < playlist.size() &&
                        newPosition >= 0 && newPosition < playlist.size()) {
                        String song = playlist.remove(currentPosition);
                        playlist.add(newPosition, song);
                    } else {
                        System.out.println("Invalid positions.");
                    }
                    break;
                case 4:
                    System.out.println("\nPlaylist:");
                    for (String song : playlist) {
                        System.out.println(song);
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
