package sorting;

public class Client {
    public static void main(String[] args) throws CloneNotSupportedException {
        EmployeeList employeeList = new EmployeeList();

        employeeList.addEmployee(new Employee(3, "Varshith", 75000));
        employeeList.addEmployee(new Employee(1, "Hari", 50000));
        employeeList.addEmployee(new Employee(2, "Harsha", 60000));

        System.out.println("Employees sorted by natural order (id):");
        employeeList.sortByNaturalOrder();
        employeeList.printAll();

        System.out.println("\nEmployees sorted by name:");
        employeeList.sortByName();
        employeeList.printAll();

        System.out.println("\nEmployees sorted by salary:");
        employeeList.sortBySalary();
        employeeList.printAll();

        System.out.println("\nIterating over employees:");
        for (Employee employee : employeeList) {
            System.out.println(employee);
        }

        System.out.println("\nCloning an employee:");
        Employee clonedEmployee = employeeList.cloneEmployee(1);
        System.out.println("Cloned Employee: " + clonedEmployee);
    }
}
