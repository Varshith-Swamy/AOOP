package sorting;

import java.util.Comparator;

public class EmployeeComparators {
    // Comparator for sorting by name
    public static final Comparator<Employee> NAME_COMPARATOR = new Comparator<Employee>() {
        @Override
        public int compare(Employee e1, Employee e2) {
            return e1.getName().compareTo(e2.getName());
        }
    };

    // Comparator for sorting by salary
    public static final Comparator<Employee> SALARY_COMPARATOR = new Comparator<Employee>() {
        @Override
        public int compare(Employee e1, Employee e2) {
            return Double.compare(e1.getSalary(), e2.getSalary());
        }
    };
}

