package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class EmployeeList implements Iterable<Employee> {
    private List<Employee> employees;

    public EmployeeList() {
        employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void sortByNaturalOrder() {
        Collections.sort(employees);
    }

    public void sortByName() {
        Collections.sort(employees, EmployeeComparators.NAME_COMPARATOR);
    }

    public void sortBySalary() {
        Collections.sort(employees, EmployeeComparators.SALARY_COMPARATOR);
    }

    @Override
    public Iterator<Employee> iterator() {
        return employees.iterator();
    }

    public Employee cloneEmployee(int index) throws CloneNotSupportedException {
        return (Employee) employees.get(index).clone();
    }

    public void printAll() {
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}
