package logging;

public class ErrorHandler extends LogHandler {
    public ErrorHandler() {
        super(LogLevel.ERROR);
    }

    @Override
    protected boolean canHandle(String message) {
        return message.contains("ERROR");
    }

    @Override
    protected void process(String message) {
        System.out.println("ERROR: " + message);
    }
}