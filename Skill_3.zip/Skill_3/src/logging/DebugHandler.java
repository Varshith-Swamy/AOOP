package logging;

public class DebugHandler extends LogHandler {
    public DebugHandler() {
        super(LogLevel.DEBUG);
    }

    @Override
    protected boolean canHandle(String message) {
        return message.contains("DEBUG");
    }

    @Override
    protected void process(String message) {
        System.out.println("DEBUG: " + message);
    }
}

