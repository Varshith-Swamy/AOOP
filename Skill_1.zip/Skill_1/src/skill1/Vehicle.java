package skill1;

interface Vehicle {
    void bookRide();
}  