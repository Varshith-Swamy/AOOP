package skill1;

class LuxuryVehicleFactory implements VehicleFactoryAbstract {
    public Vehicle createCar() {
        return new Car();  // Pretend this is a luxury car
    }

    public Vehicle createBike() {
        return new Bike(); // Pretend this is a luxury bike
    }

    public Vehicle createScooter() {
        return new Scooter(); // Pretend this is a luxury scooter
    }
}