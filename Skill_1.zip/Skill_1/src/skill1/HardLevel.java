package skill1;

class HardLevel implements Level {
    public void startLevel() {
        System.out.println("Starting Hard Level...");
    }
}