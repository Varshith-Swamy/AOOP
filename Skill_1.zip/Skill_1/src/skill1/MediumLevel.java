package skill1;

class MediumLevel implements Level {
    public void startLevel() {
        System.out.println("Starting Medium Level...");
    }
}