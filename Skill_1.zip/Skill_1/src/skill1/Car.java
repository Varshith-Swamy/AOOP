package skill1;

class Car implements Vehicle {
    public void bookRide() {
        System.out.println("Car ride booked!");
    }
}