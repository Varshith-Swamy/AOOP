package skill1;

class RideManager {
    private static RideManager instance;

    private RideManager() {
        // private constructor
    }

    public static RideManager getInstance() {
        if (instance == null) {
            instance = new RideManager();
        }
        return instance;
    }

    public void requestRide(String vehicleType) {
        System.out.println("Ride requested for: " + vehicleType);
    }
}