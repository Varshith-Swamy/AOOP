package skill1;

class RideSharingApp {
    private VehicleFactoryAbstract factory;

    public RideSharingApp(VehicleFactoryAbstract factory) {
        this.factory = factory;
    }

    public void requestLuxuryRide() {
        Vehicle car = factory.createCar();
        car.bookRide();
    }

    public void requestEconomyRide() {
        Vehicle bike = factory.createBike();
        bike.bookRide();
    }
}