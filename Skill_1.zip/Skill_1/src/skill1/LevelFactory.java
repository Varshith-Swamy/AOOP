package skill1;

class LevelFactory {
    public Level createLevel(String difficulty) {
        if (difficulty.equalsIgnoreCase("easy")) {
            return new EasyLevel();
        } else if (difficulty.equalsIgnoreCase("medium")) {
            return new MediumLevel();
        } else if (difficulty.equalsIgnoreCase("hard")) {
            return new HardLevel();
        } else {
            throw new IllegalArgumentException("Unknown difficulty: " + difficulty);
        }
    }
}