package skill1;

class VehicleFactory {
    public Vehicle createVehicle(String vehicleType) {
        if (vehicleType.equalsIgnoreCase("car")) {
            return new Car();
        } else if (vehicleType.equalsIgnoreCase("bike")) {
            return new Bike();
        } else if (vehicleType.equalsIgnoreCase("scooter")) {
            return new Scooter();
        } else {
            throw new IllegalArgumentException("Unknown vehicle type: " + vehicleType);
        }
    }
}