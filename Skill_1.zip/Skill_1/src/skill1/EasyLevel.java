package skill1;

class EasyLevel implements Level {
    public void startLevel() {
        System.out.println("Starting Easy Level...");
    }
}