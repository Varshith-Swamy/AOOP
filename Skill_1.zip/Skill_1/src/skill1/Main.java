package skill1;

public class Main {
    public static void main(String[] args) {
        // Singleton pattern for game manager
        GameManager gameManager = GameManager.getInstance();
        gameManager.startGame();

        // Factory pattern for game levels
        LevelFactory levelFactory = new LevelFactory();
        Level easy = levelFactory.createLevel("easy");
        easy.startLevel();

        // Singleton pattern for ride-sharing manager
        RideManager rideManager = RideManager.getInstance();
        rideManager.requestRide("Car");

        // Abstract Factory pattern for vehicle selection
        VehicleFactoryAbstract economyFactory = new EconomyVehicleFactory();
        RideSharingApp rideApp = new RideSharingApp(economyFactory);
        rideApp.requestEconomyRide();
    }
}
