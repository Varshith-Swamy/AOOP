package skill1;

interface VehicleFactoryAbstract {
    Vehicle createCar();
    Vehicle createBike();
    Vehicle createScooter();
}