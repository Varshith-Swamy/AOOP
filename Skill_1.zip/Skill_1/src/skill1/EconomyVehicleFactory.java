package skill1;

class EconomyVehicleFactory implements VehicleFactoryAbstract {
    public Vehicle createCar() {
        return new Car();
    }

    public Vehicle createBike() {
        return new Bike();
    }

    public Vehicle createScooter() {
        return new Scooter();
    }
}