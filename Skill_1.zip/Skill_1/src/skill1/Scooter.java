package skill1;

class Scooter implements Vehicle {
    public void bookRide() {
        System.out.println("Scooter ride booked!");
    }
}