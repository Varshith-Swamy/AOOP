package skill1;

interface Level {
    void startLevel();
}