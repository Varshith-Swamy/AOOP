package skill1;

class Bike implements Vehicle {
    public void bookRide() {
        System.out.println("Bike ride booked!");
    }
}