package music;

class OnlineStreamingService {
    public void playStreaming() {
        System.out.println("Playing music from an online streaming service.");
    }

    public void stopStreaming() {
        System.out.println("Stopped playing music from an online streaming service.");
    }
}