package music;

public class OnlineStreamingAdapter implements MusicSource {
    private OnlineStreamingService onlineStreamingService;

    public OnlineStreamingAdapter() {
        this.onlineStreamingService = new OnlineStreamingService();
    }

    @Override
    public void play() {
        onlineStreamingService.playStreaming();
    }

    @Override
    public void stop() {
        onlineStreamingService.stopStreaming();
    }
}