package music;

public class RadioStationAdapter implements MusicSource {
    private RadioStation radioStation;

    public RadioStationAdapter() {
        this.radioStation = new RadioStation();
    }

    @Override
    public void play() {
        radioStation.playRadio();
    }

    @Override
    public void stop() {
        radioStation.stopRadio();
    }
}